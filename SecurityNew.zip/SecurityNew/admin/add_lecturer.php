<div class="row-fluid">
    <!-- block -->
    <div class="block">
        <div class="navbar navbar-inner block-header">
            <div class="muted pull-left">Add lecturer</div>
        </div>
        <div class="block-content collapse in">
            <div class="span12">
                <form method="post">
                    <div class="control-group">
                        <label>Department:</label>
                        <div class="controls">
                            <select name="department" class="" required>
                                <option></option>
                                <?php
                                $query = mysqli_query($connection, "SELECT * from department order by department_name");
                                while ($row = mysqli_fetch_array($query)) {
                                    ?>
                                    <option value="<?php echo $row['department_id']; ?>"><?php echo $row['department_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="firstname" id="focusedInput" type="text" placeholder="Firstname">
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="lastname" id="focusedInput" type="text" placeholder="Lastname">
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <button name="save" class="btn btn-info"><i class="icon-plus-sign icon-large"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /block -->
</div>

<?php
if (isset($_POST['save'])) {
    $user_access_level = $_SESSION['access_level'];
    if ($user_access_level < 5) {
        ?>
        <div class="alert alert-error">
            <strong>Error!</strong> You do not have the required access level to add a lecturer.
        </div>
        <?php
    } else {
        $firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
        $lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
        $department_id = mysqli_real_escape_string($connection, $_POST['department']);

        $query = mysqli_query($connection, "SELECT * from lecturer where firstname = '$firstname' and lastname = '$lastname' ") or die(mysqli_error($connection));
        $count = mysqli_num_rows($query);

        if ($count > 0) {
            ?>
            <script>
                alert('Data Already Exist');
            </script>
            <?php
        } else {
            // Omitting lecturer_id since it's assumed to be auto-incrementing
            mysqli_query($connection, "INSERT INTO lecturer (firstname,lastname,location,department_id)
                                values ('$firstname','$lastname','uploads/NO-IMAGE-AVAILABLE.jpg','$department_id')") or die(mysqli_error($connection));
            ?>
            <script>
                window.location = "lecturer.php";
            </script>
            <?php
        }
    }
}
?>

