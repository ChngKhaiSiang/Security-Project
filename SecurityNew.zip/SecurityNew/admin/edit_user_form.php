   <div class="row-fluid">
   <a href="admin_user.php" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add user</a>
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Edit User</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
								<?php
								$query = mysqli_query($connection, "SELECT * from users where user_id = '$get_id'")or die(mysqli_error($connection));
								$row = mysqli_fetch_array($query);
								?>
								<form method="post">
										<div class="control-group">
                                          <div class="controls">
                                            <input class="input focused" value="<?php echo $row['firstname']; ?>" name="firstname" id="focusedInput" type="text" placeholder = "Firstname" required>
                                          </div>
                                        </div>
										
										<div class="control-group">
                                          <div class="controls">
                                            <input class="input focused" value="<?php echo $row['lastname']; ?>"  name="lastname" id="focusedInput" type="text" placeholder = "Lastname" required>
                                          </div>
                                        </div>
										
											<div class="control-group">
                                          <div class="controls">
                                            <input class="input focused" value="<?php echo $row['username']; ?>"  name="username" id="focusedInput" type="text" placeholder = "Username" required>
                                          </div>
                                        </div>
										
                      <div class="control-group">
                                          <div class="controls">
                                            <input class="input focused" value="<?php echo $row['access_level']; ?>"  name="access_level" id="focusedInput" type="text" placeholder = "Access level" required>
                                          </div>
                                        </div>                  
								
										
											<div class="control-group">
                                          <div class="controls">
												<button name="update" class="btn btn-success"><i class="icon-save icon-large"></i></button>

                                          </div>
                                        </div>
                                </form>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
			<?php		
if (isset($_POST['update'])){

  $user_access_level = $_SESSION['access_level'];

  if ($user_access_level<5)
  {
    
  }
  else
  {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $access_level = $_POST['access_level'];


    mysqli_query($connection, "UPDATE users set username = '$username'  , firstname = '$firstname' , lastname = '$lastname' , access_level = '$access_level' where user_id = '$get_id' ")or die(mysqli_error($connection));

    mysqli_query($connection, "INSERT INTO activity_log (date,username,action) values(NOW(),'$user_username','Edit User $username')")or die(mysqli_error($connection));
    ?>
    <script>
      window.location = "admin_user.php"; 
    </script>
    <?php
  }
}
?>