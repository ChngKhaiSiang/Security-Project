<?php
include('dbcon.php');
session_start();

// Input Validation
$username = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Use Prepared Statements for Input Validation
$stmt = mysqli_prepare($connection, "SELECT * FROM users WHERE username=?");
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    // Output Encoding and Error Handling
    try {
        $row = mysqli_fetch_array($result);

        if ($row && password_verify($password, $row['password'])) {
            // Password is correct
            $_SESSION['id'] = htmlspecialchars($row['user_id'], ENT_QUOTES, 'UTF-8');
            $_SESSION['access_level'] = htmlspecialchars($row['access_level'], ENT_QUOTES, 'UTF-8');
            echo 'true';

            // Inserting into user_log using prepared statements
            $logStmt = mysqli_prepare($connection, "INSERT into user_log (username, login_date, user_id) values (?, NOW(), ?)");
            mysqli_stmt_bind_param($logStmt, "si", $username, $row['user_id']);
            mysqli_stmt_execute($logStmt);
        } else {
            // Password is incorrect or user doesn't exist
            echo "Invalid username or password";
        }
    } catch (Exception $e) {
        // Log or display a generic error message
        echo "An unexpected error occurred. Please try again later.";
    }
} else {
    // Log or display an error message
    echo "Database error. Please try again later.";
}

// Close prepared statements
mysqli_stmt_close($stmt);
mysqli_stmt_close($logStmt);
mysqli_close($connection);
?>
