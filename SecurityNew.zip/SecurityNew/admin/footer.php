<div class="pull-right">
		<footer>
           <p>ULTIMATE UNIVERSITY ONLINE LMS ADMIN </p>
        <footer>
</div>