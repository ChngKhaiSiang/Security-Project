<?php  include('header.php'); ?>
<?php  include('session.php'); ?>
    <body>
		<?php include('navbar.php') ?>
        <div class="container-fluid">
            <div class="row-fluid">
					<?php include('sidebar_dashboard.php'); ?>
                <!--/span-->
                <div class="span9" id="content">
						<div class="row-fluid"></div>
						
                    <div class="row-fluid">
            
                        <!-- block -->
                        <div id="block_bg" class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Data Numbers</div>
                            </div>
                            <div class="block-content collapse in">
							        <div class="span12">
						
									<?php 
								$query_reg_lecturer = mysqli_query($connection, "SELECT * from lecturer where lecturer_status = 'Registered' ")or die(mysqli_error($connection));
								$count_reg_lecturer = mysqli_num_rows($query_reg_lecturer);
								?>
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_reg_lecturer; ?>"><?php echo $count_reg_lecturer; ?></div>
                                    <div class="chart-bottom-heading"><strong>Registered lecturer</strong>

                                    </div>
                                </div>
								
								<?php 
								$query_lecturer = mysqli_query($connection, "SELECT * from lecturer")or die(mysqli_error($connection));
								$count_lecturer = mysqli_num_rows($query_lecturer);
								?>
								
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_lecturer; ?>"><?php echo $count_lecturer ?></div>
                                    <div class="chart-bottom-heading"><strong>Lecturer</strong>

                                    </div>
                                </div>
								
								<?php 
								$query_student = mysqli_query($connection, "SELECT * from student where status='Registered'")or die(mysqli_error($connection));
								$count_student = mysqli_num_rows($query_student);
								?>
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_student ?>"><?php echo $count_student ?></div>
                                    <div class="chart-bottom-heading"><strong>Registered Students</strong>

                                    </div>
                                </div>
								
								
										<?php 
								$query_student = mysqli_query($connection, "SELECT * from student")or die(mysqli_error($connection));
								$count_student = mysqli_num_rows($query_student);
								?>
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_student ?>"><?php echo $count_student ?></div>
                                    <div class="chart-bottom-heading"><strong>Students</strong>

                                    </div>
                                </div>
								
								
								
								
							
								
									<?php 
								$query_class = mysqli_query($connection, "SELECT * from class")or die(mysqli_error($connection));
								$count_class = mysqli_num_rows($query_class);
								?>
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_class; ?>"><?php echo $count_class; ?></div>
                                    <div class="chart-bottom-heading"><strong>Class</strong>

                                    </div>
                                </div>
								
								
										<?php 
								$query_file = mysqli_query($connection, "SELECT * from files")or die(mysqli_error($connection));
								$count_file = mysqli_num_rows($query_file);
								?>
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_file; ?>"><?php echo $count_file; ?></div>
                                    <div class="chart-bottom-heading"><strong>Downloadable File</strong>

                                    </div>
                                </div>
								
								
										<?php 
								$query_subject = mysqli_query($connection, "SELECT * from subject")or die(mysqli_error($connection));
								$count_subject = mysqli_num_rows($query_subject);
								?>
								
                                <div class="span3">
                                    <div class="chart" data-percent="<?php echo $count_subject; ?>"><?php echo $count_subject; ?></div>
                                    <div class="chart-bottom-heading"><strong>Subjects</strong>

                                    </div>
                                </div>
						
						
                            </div>
                        </div>
                        <!-- /block -->
						
                    </div>
                    </div>
                
                
                 
                 
                </div>
            </div>
    
         <?php include('footer.php'); ?>
        </div>
	<?php include('script.php'); ?>
    </body>

</html>