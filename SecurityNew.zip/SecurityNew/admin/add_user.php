<div class="row-fluid">
    <!-- block -->
    <div class="block">
        <div class="navbar navbar-inner block-header">
            <div class="muted pull-left">Add User</div>
        </div>
        <div class="block-content collapse in">
            <div class="span12">
                <form method="post">
                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="firstname" id="focusedInput" type="text" placeholder="Firstname" required>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="lastname" id="focusedInput" type="text" placeholder="Lastname" required>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="username" id="focusedInput" type="text" placeholder="Username" required>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="password" id="focusedInput" type="password" placeholder="Password" required>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <input class="input focused" name="access_level" id="focusedInput" type="text" placeholder="Access level" required>
                        </div>
                    </div>

                    <div class="control-group">
                        <div class="controls">
                            <button name="save" class="btn btn-info"><i class="icon-plus-sign icon-large"></i> Add User</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /block -->
</div>

<?php
if (isset($_POST['save'])) {
    $user_access_level = $_SESSION['access_level'];
    if ($user_access_level <5) {
        ?>
        <div class="alert alert-error">
            <strong>Error!</strong> You do not have the required access level to add a user.
        </div>
        <?php
    } else {
        $firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
        $lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
        $username = mysqli_real_escape_string($connection, $_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
        $access_level = mysqli_real_escape_string($connection, $_POST['access_level']);

        $query = mysqli_query($connection, "SELECT * from users where username = '$username'") or die(mysqli_error($connection));
        $count = mysqli_num_rows($query);

        if ($count > 0) {
            ?>
            <div class="alert alert-error">
                <strong>Error!</strong> Data already exists.
            </div>
            <?php
        } else {
            mysqli_query($connection, "INSERT INTO users (username,password,firstname,lastname,access_level) values('$username','$password','$firstname','$lastname','$access_level')") or die(mysqli_error($connection));

            mysqli_query($connection, "INSERT INTO activity_log (date,username,action) values(NOW(),'$user_username','Add User $username')") or die(mysqli_error($connection));
            ?>
            <div class="alert alert-success">
                <strong>Success!</strong> User added successfully.
            </div>
            <script>
                setTimeout(function () {
                    window.location = "admin_user.php";
                }, 2000);
            </script>
            <?php
        }
    }
}
?>
