<?php
include('admin/dbcon.php');
session_start();

// Function to sanitize and validate user input
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to log user login
function log_user_login($username, $userId) {
    global $connection;
    $query_log = "INSERT INTO user_log (username, login_date, user_id) VALUES (?, NOW(), ?)";
    $stmt_log = mysqli_prepare($connection, $query_log);
    mysqli_stmt_bind_param($stmt_log, 'si', $username, $userId);
    mysqli_stmt_execute($stmt_log);
    mysqli_stmt_close($stmt_log);
}

// Validate and sanitize input
$username = clean_input($_POST['username']);
$password = clean_input($_POST['password']);

// Student login
$query_student = "SELECT student_id, password FROM student WHERE username = ?";
$stmt = mysqli_prepare($connection, $query_student);
mysqli_stmt_bind_param($stmt, 's', $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

// Lecturer login
$query_lecturer = "SELECT lecturer_id, password FROM lecturer WHERE username = ?";
$stmt_lecturer = mysqli_prepare($connection, $query_lecturer);
mysqli_stmt_bind_param($stmt_lecturer, 's', $username);
mysqli_stmt_execute($stmt_lecturer);
$result_lecturer = mysqli_stmt_get_result($stmt_lecturer);
$row_lecturer = mysqli_fetch_assoc($result_lecturer);

// Proper error handling
if (!$stmt || !$stmt_lecturer) {
    die("Query failed: " . mysqli_error($connection));
}

if ($row && password_verify($password, $row['password'])) {
    $_SESSION['id'] = $row['student_id'];
    echo 'true_student';
    log_user_login($username, $row['student_id']);
} elseif ($row_lecturer && password_verify($password, $row_lecturer['password'])) {
    $_SESSION['id'] = $row_lecturer['lecturer_id'];
    echo 'true';
    log_user_login($username, $row_lecturer['lecturer_id']);
} else {
    echo 'false';
}

// Close prepared statements
mysqli_stmt_close($stmt);
mysqli_stmt_close($stmt_lecturer);

// Close database connection
mysqli_close($connection);
?>
