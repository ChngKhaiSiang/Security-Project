<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $otp = $_POST['otp'];

    // Store the OTP in the session
    $_SESSION['otp'] = $otp;

    // Create a new PHPMailer instance
    $mail = new PHPMailer();

    // Email Configuration
    $mail->isSMTP(); // Set mailer to use SMTP
    $mail->Host = SMTP_HOST; // Specify the SMTP server
    $mail->Port = SMTP_PORT; // Specify the SMTP port
    $mail->SMTPSecure = SMTP_SECURE; // Enable encryption, 'ssl' also accepted
    $mail->SMTPAuth = SMTP_AUTH; // Enable SMTP authentication
    $mail->Username = SMTP_USERNAME; // Gmail email address
    $mail->Password = SMTP_PASSWORD; // Gmail password

    // Create a dynamic "From" address
    $noReplyEmail = NO_REPLY_EMAIL; // Replace with domain
    $mail->setFrom($noReplyEmail, 'No Reply');

    // Recipient
    $mail->addAddress($email);

    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'One-Time Password (OTP)';
    $mail->Body = 'Your OTP for password reset is: ' . $otp;

    // Send the email
    if ($mail->send()) {
        echo 'true'; // OTP sent successfully
    } else {
        echo 'false'; // Failed to send OTP
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
} else {
    // Invalid request
    echo 'false';
}
?>
