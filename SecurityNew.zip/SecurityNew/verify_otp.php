<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_otp = $_POST['otp'];
    $stored_otp = $_SESSION['otp'];

    if ($user_otp == $stored_otp) {
        // OTP verification successful
        echo 'true';
        // Clear the session variable to prevent reuse of the same OTP
        unset($_SESSION['otp']);
    } else {
        // Incorrect OTP
        echo 'false';
    }
} else {
    // Invalid request
    echo 'false';
}
?>
