<?php
include('admin/dbcon.php');
session_start();

// Validate and sanitize input
$username = mysqli_real_escape_string($connection, $_POST['username']);
$password = mysqli_real_escape_string($connection, $_POST['password']);
$firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
$lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
$class_id = mysqli_real_escape_string($connection, $_POST['class_id']);

// Use prepared statement to prevent SQL injection
$query = mysqli_prepare($connection, "SELECT * FROM student WHERE username=? AND firstname=? AND lastname=? AND class_id=?");
mysqli_stmt_bind_param($query, "sssi", $username, $firstname, $lastname, $class_id);
mysqli_stmt_execute($query);

$result = mysqli_stmt_get_result($query);

$row = mysqli_fetch_array($result);
$id = $row['student_id'];

$count = mysqli_num_rows($result);

if ($count > 0) {
    // Use password_hash for secure password hashing
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Update hashed password and set status to 'Registered'
    $updateQuery = mysqli_prepare($connection, "UPDATE student SET password=?, status='Registered' WHERE student_id=?");
    mysqli_stmt_bind_param($updateQuery, "si", $hashed_password, $id);
    mysqli_stmt_execute($updateQuery);

    $_SESSION['id'] = $id;
    echo 'true';
} else {
    echo 'false';
}

// Close prepared statements
mysqli_stmt_close($query);
mysqli_stmt_close($updateQuery);
mysqli_close($connection);
?>
