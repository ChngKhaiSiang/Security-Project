<?php
include('admin/dbcon.php');
session_start();

// Validate and sanitize user input
$username = mysqli_real_escape_string($connection, $_POST['username']);
$password = mysqli_real_escape_string($connection, $_POST['password']);
$firstname = mysqli_real_escape_string($connection, $_POST['firstname']);
$lastname = mysqli_real_escape_string($connection, $_POST['lastname']);
$department_id = mysqli_real_escape_string($connection, $_POST['department_id']);

// Input validation
if (empty($username) || empty($password) || empty($firstname) || empty($lastname) || empty($department_id)) {
    echo 'false';
    exit();
}

$query = mysqli_query($connection, "SELECT * FROM lecturer WHERE firstname='$firstname' AND lastname='$lastname' AND department_id = '$department_id'") or die(mysqli_error($connection));
$row = mysqli_fetch_array($query);
$id = $row['lecturer_id'];

$count = mysqli_num_rows($query);

if ($count > 0) {
    // Use password_hash for secure password hashing
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    // User already exists, update their information
    mysqli_query($connection, "UPDATE lecturer SET username='$username', password='$hashed_password', lecturer_status='Registered' WHERE lecturer_id='$id'") or die(mysqli_error($connection));
    $_SESSION['id'] = $id;
    echo 'true';
} else {
    // User does not exist, insert a new record
    $result = mysqli_query($connection, "INSERT INTO lecturer (username, password, firstname, lastname, department_id, lecturer_status) VALUES ('$username', '$hashed_password', '$firstname', '$lastname', '$department_id', 'Registered')") or die(mysqli_error($connection));

    if ($result) {
        $id = mysqli_insert_id($connection);
        $_SESSION['id'] = $id;
        echo 'true';
    } else {
        // Handle the error appropriately, log it, and provide a user-friendly message
        echo 'false';
    }
}
?>