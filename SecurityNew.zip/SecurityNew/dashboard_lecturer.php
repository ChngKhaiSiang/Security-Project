<?php include('header_dashboard.php'); ?>
<?php include('session.php'); ?>
    <body id="class_div">
		<?php include('navbar_lecturer.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
				<?php include('lecturer_sidebar.php'); ?>
                <div class="span6" id="content">
                     <div class="row-fluid">
					    <!-- breadcrumb -->	
					     <ul class="breadcrumb">
								<?php
								$school_year_query = mysqli_query($connection, "SELECT * from school_year order by school_year DESC")or die(mysqli_error($connection));
								$school_year_query_row = mysqli_fetch_array($school_year_query);
								$school_year = $school_year_query_row['school_year'];
								?>
								<li><a href="#"><b>My Class</b></a><span class="divider">/</span></li>
								<li><a href="#">School Year: <?php echo $school_year_query_row['school_year']; ?></a></li>
						</ul>
						 <!-- end breadcrumb -->

						 <!-- Security Guidelines -->
						 <div class="alert alert-info">
							<strong>Security Guidelines:</strong>
							<ul>
								<li>Ensure that your password is strong and not easily guessable. Use a combination of uppercase, lowercase, numbers, and symbols.</li>
								<li>Do not share your login credentials with anyone. Each user is responsible for their own account security.</li>
								<li>Always log out of the system when done to prevent unauthorized access, especially on shared computers.</li>
								<li>Report any suspicious activities or security concerns to the system administrator immediately.</li>
								<li>Be cautious of phishing attempts. The system will never ask for sensitive information via email or pop-ups.</li>
							</ul>
                    	</div>
                    	<!-- End Security Guidelines -->
						
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="count_class" class="muted pull-right"></div>
								</div>
                            <div class="block-content collapse in">
                                <div class="span12">
										<?php include('lecturer_class.php'); ?>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
									<script type="text/javascript">
									$(document).ready( function() {
										$('.remove').click( function() {
										var id = $(this).attr("id");
											$.ajax({
											type: "POST",
											url: "delete_class.php",
											data: ({id: id}),
											cache: false,
											success: function(html){
											$("#del"+id).fadeOut('slow', function(){ $(this).remove();}); 
											$('#'+id).modal('hide');
											$.jGrowl("Your Class is Successfully Deleted", { header: 'Class Delete' });
											}
											}); 	
											return false;
										});				
									});
									</script>
                </div>
				<?php include('lecturer_right_sidebar.php') ?>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>