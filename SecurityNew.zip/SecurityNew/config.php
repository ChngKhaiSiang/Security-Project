<?php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_AUTH', true);
define('SMTP_USERNAME', 'pangkheryong@gmail.com');
define('SMTP_PASSWORD', 'ctlb lozs nbbi ukqg');
define('NO_REPLY_EMAIL', 'no-reply@yourdomain.com');
?>