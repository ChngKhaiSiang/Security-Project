<form id="signin_lecturer" class="form-signin" method="post">
    <h3 class="form-signin-heading"><i class="icon-lock"></i> Sign up as lecturer</h3>
    <input type="text" class="input-block-level" name="firstname" placeholder="Firstname" pattern="[a-zA-Z]+" title="Alphabetic characters only" required>
    <input type="text" class="input-block-level" name="lastname" placeholder="Lastname" pattern="[a-zA-Z]+" title="Alphabetic characters only" required>
    <label>Department</label>
    <select name="department_id" class="input-block-level span12" required>
        <option></option>
        <?php
        $query = mysqli_query($connection, "SELECT * from department order by department_name") or die(mysqli_error($connection));
        while ($row = mysqli_fetch_array($query)) {
            echo '<option value="' . htmlspecialchars($row['department_id'], ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($row['department_name'], ENT_QUOTES, 'UTF-8') . '</option>';
        }
        ?>
    </select>
    <input type="text" class="input-block-level" id="username" name="username" placeholder="Username" pattern="[a-zA-Z0-9]+" title="Alphanumeric characters only" required>
    <input type="password" class="input-block-level" id="password" name="password" placeholder="Password" required>
    <input type="password" class="input-block-level" id="cpassword" name="cpassword" placeholder="Re-type Password" required>
    
    <!-- Add radio button for terms and conditions -->
    <label class="checkbox">
        <input type="radio" name="terms" value="accepted" required>
        I accept the <a href="terms_and_conditions.php" target="_blank">Terms and Conditions</a>
    </label>
    
    <button id="signin" name="login" class="btn btn-info" type="submit"><i class="icon-check icon-large"></i> Sign Up</button>
</form>

<script>
    jQuery(document).ready(function () {
        jQuery("#signin_lecturer").submit(function (e) {
            e.preventDefault();
            var password = jQuery('#password').val();
            var cpassword = jQuery('#cpassword').val();
            var termsAccepted = jQuery('input[name=terms]:checked').val();

            if (password == cpassword && termsAccepted === 'accepted') {
                var formData = jQuery(this).serialize();
                $.ajax({
                    type: "POST",
                    url: "lecturer_signup.php",
                    data: formData,
                    success: function (html) {
                        if (html == 'true') {
                            $.jGrowl("Welcome to Ultimate University Learning Management System", { header: 'Sign up Success' });
                            var delay = 1000;
                            setTimeout(function () { window.location = 'dashboard_lecturer.php' }, delay);
                        } else {
                            $.jGrowl("Please check your data and try again.", { header: 'Sign Up Failed' });
                        }
                    }
                });
            } else {
                $.jGrowl("Passwords do not match or Terms and Conditions not accepted", { header: 'Sign Up Failed' });
            }
        });
    });
</script>
<a onclick="window.location='index.php'" id="btn_login" name="login" class="btn" type="submit"><i class="icon-signin icon-large"></i> Click here to Login</a>